<?php

require "mysql_connect.php";
$result=mysql_query("select *from news");
$n=0;
while($row=mysql_fetch_array($result)){


$arr[$n++]=array("title"=>$row['title'],
"url"=>$row['url']



);




}


echo json_encode($arr);



?>