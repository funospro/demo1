<?php
include_once "fun.php";

while( !!$return=info('userinfo')){
print_r($return['user']);
}


?>