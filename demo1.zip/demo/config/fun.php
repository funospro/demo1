<?php
function query($sql){


$con=mysql_connect("localhost","root","");
	
	 mysql_select_db("demo", $con);

mysql_query( "set names utf8");
return mysql_query($sql);

}

 function info($biao){
$sql="SELECT* FROM `$biao` ";
$result=query($sql);
$row=mysql_fetch_assoc($result);
return $row;


}
?>