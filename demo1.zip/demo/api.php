<?php
    $ch = curl_init();
    $trans=$_GET['query'];
    $url = 'http://apis.baidu.com/apistore/tranlateservice/translate?query='.$trans.'&from=en&to=zh';
    $header = array(
        'apikey: 60ec0b9f38f8aed26e503f31512d05c6',
    );
    // 添加apikey到header
    curl_setopt($ch, CURLOPT_HTTPHEADER  , $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // 执行HTTP请求
    curl_setopt($ch , CURLOPT_URL , $url);
    $res = curl_exec($ch);

    var_dump(json_decode($res));

?>