<?php

include_once "config/fun.php";

$biao='page';
$sql="SELECT* FROM `page`";
$result=query($sql);
while(!!$row=mysql_fetch_assoc($result)){




echo <<<STR
<li><a  href='read.php?query={$row['name']}' >{$row['name']}</a></li>
STR;
}




	 ?>