<?php

include_once "config/fun.php";

	 $_name=$_POST['name'];
$_password=$_POST['password'];

//echo $_name;

	if(strlen($_name)>4){

	$password=md5($_password);
	
	$sql= " SELECT *FROM `userinfo` WHERE `user`={$_name} ";

$biao='userinfo';


$result=query($sql);
$row=mysql_fetch_assoc($result);
if($row['password']==$password){
	
	setcookie("funos",$_name);
	header('location:forum.php');
	}
	else{
	
	
	echo "密码不对";
	
	
	}
}

?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>登录</title>
<meta name="keywords" content="欢迎使用本引导安装程序" />
<meta name="description" content="欢迎使用本引导安装程序" />
<style type="text/css">
body {
	background:#f7f7f7;
	font-size:14px;
}
#main {
	width:560px;
	height:490px;
	background:#fff;
	border:1px solid #ddd;
	position:absolute;
	top:50%;
	left:50%;
	margin-left:-280px;
	margin-top:-280px;
}
#main .title {
	height: 48px;
	line-height: 48px;
	color:#333;
	font-size:16px;
	font-weight:bold;
	text-indent:30px;
	border-bottom:1px dashed #eee;
}
#main form {
	width:400px;
	margin:20px 0 0 10px;
}
#main form label {
	margin:10px 0 0 0;
	display:block;
	text-align:right;
}
#main form label input.text {
	width:200px;
	height:25px;
}

#main form label input.submit {
	width:204px;
	display:block;
	height:35px;
	cursor:pointer;
	float:right;
}
</style>
</head>
<body>
	<div id="main">
		<div class="title">登录</div>
		<form method="post">
			<label>account:<input class="text" type="text" name="name"  /></label>
			<label>password：<input class="text" type="password" name="password" /></label>
		
			<br /><br />
	
			<label><input class="submit" type="submit" name="submit" value="确定" /></label>
		
		</form>
		 	<a href='index.php'>登录</a>
		
		
	</div>
</body>
</html>

