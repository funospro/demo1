<?php
function __autoload($_classname){


require $_classname.'.class.php';
}

$fun=new Mysqls();
$sql="SELECT *FROM `userinfo`";
$result=$fun->query($sql);

?>