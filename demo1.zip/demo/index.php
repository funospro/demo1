<?php

if(!isset($_COOKIE['funos'])){
	
	 header('location:login.inc.php');
	
	
	
	}
else{
header('location:forum.php');
	
	



}




?>