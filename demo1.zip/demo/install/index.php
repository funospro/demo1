<?php 
$dbhost = 'localhost';
 $dbuser = 'root'; 
$dbpass = '';
 $conn = mysql_connect($dbhost, $dbuser, $dbpass); 
if(! $conn ) { 
die('连接失败: ' . mysql_error());
 } 
echo '连接成功<br />'; 
$sql = "CREATE TABLE user( ". "id INT NOT NULL AUTO_INCREMENT, ". "name text(100) NOT NULL, ". "runoob_author VARCHAR(40) NOT NULL, ". "submission_date DATE, ". "PRIMARY KEY ( id )); "; 
mysql_select_db( 'install' ); 
$retval = mysql_query( $sql, $conn ); 
if(! $retval ) { 
die('数据表创建失败: ' . mysql_error()); 
}
 echo "数据表创建成功\n";
 mysql_close($conn); ?>