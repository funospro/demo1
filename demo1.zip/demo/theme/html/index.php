<html>

<head>

<meta charset="utf-8">

<title>demo1</title>

</head>

<body>


<div id="picture">
<?
require "../../picture.php";
?>
</div>
</body>
</html>
