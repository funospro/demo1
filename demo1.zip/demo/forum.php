<?php
if(!isset($_COOKIE['funos'])){
	
	 header('location:login.inc.php');
	
	
	
	}
	
	require 'picture.php';
	require 'content.php';
	
echo"	<a href='writer.php'>发文章</a>";

?>