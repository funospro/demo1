<?php
include_once "config/fun.php";
if(isset($_COOKIE['funos'])){
if(isset( $_POST['name'] )){
	 $_name=$_POST['name'];
$_page=$_POST['page'];
$user=$_COOKIE['funos'];
$date=date('20y年m月d日 h:i',time() );
//echo $_name;

	if(strlen($_name)>18){
		exit("名字过长");
		
		}
	
		
	$sqls= "insert into `page` (`name`,`page`,`user`,`date`) Values('$_name','$_page','$user','$date')";
		

query($sqls); 
header('location:index.php');
	

}



}


else{


header('location:index.php');
	

}
/*function __autoload($_classname){


require $_classname.'.class.php';
}*/

		
//$fun=new Mysql();


?>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Funos</title>
<script src="theme/jquery.js"></script>
    </head>
    <body>
    
<form action='' method='post'>
Number:<input type='text'  name='name'><br/>

文章:<textarea name="page" cols="30" rows="10"></textarea><br/>
<span>还可以输入<strong style="color:red">140 </strong> 个字</span>
<script>
var MAX_LENGTH=140;
$("textarea").keyup(function(){
var l=$(this).val().length;
$("strong").text(MAX_LENGTH-l);
if(parseInt($("strong").text())<0){
$("strong").text("0");
var v=$(this).val().substring(0,141);
$(this).val(v);


}

});

</script>


	<br/>
	
<input type='submit'  value='发表'></body>
</form>
  </body>
</html>
