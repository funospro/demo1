<html>

<head>

<meta charset="utf-8">

<title>demo1</title>
<style  src="theme/display.css"></style>
</head>

<body>


<div id="picture">
<?
require "picture.php";
?>
</div>
<?
require "content.php";
?>

<div  id="content">



</div>
</body>
</html>
