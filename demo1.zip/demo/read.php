<?php
include_once "config/fun.php";

$pages=$_GET['query'];
$sql="SELECT* FROM `page` WHERE `name`='{$pages}'";
$result=query($sql);

$row=mysql_fetch_assoc($result);
$pattern=array(

'/(.*?)\\n/',
'/public/',

'/class/',
'/android/',
'/java/',
"/http:\/\/(.*?)\.(.*?)\.(.*?)<(.*?)>/"

);
$str=$row['page'];
$str1=array("<div style='color:black'>$1</div>",

"<span style='color:blue'>public</span>",

"<span style='color:blue'>class</span>",
"<span style='color:blue'>android</span>",
"<span style='color:blue'>java</span>",
"<a href ='http://$1.$2.$3'>$4</a>"


);
$preg= preg_replace($pattern,$str1,$str);


echo <<<AAA
<div>

<p> 编辑者:{$row['user']}</p>

<p> 时 间:{$row['date']}</p>


</div>
     <div >内容:{$preg}</div>
AAA;


?>