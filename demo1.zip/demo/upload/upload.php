<?php
echo "<pre>";
print_r($_FILES);
$dirName=date("ymd");
if(!is_dir($dirName)){
	mkdir($dirName);
	
	
	}
if(is_uploaded_file($_FILES['upfile']['tmp_name'])){
	
	$toName=$dirName.'/'.time().$_FILES['upfile']['name'];
if( move_uploaded_file($_FILES['upfile']['tmp_name'],$toName)
)	{
echo"<script>alert('上传成功')</script>";

}	}
?>
<form action='' method='post' enctype='multipart/form-data' >

<input type='file' name='upfile'/>

<input type='submit' value='上传' name='submit'/>

</form>