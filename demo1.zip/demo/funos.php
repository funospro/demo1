<?php
if(isset($_GET['work'])){
$get=$_GET['work'];
include_once  $get.".php";

}


?>
