
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Funos</title>
    </head>
    <body>
<h1>Funos.pro</h>
<a href="index.php?query=login.inc.php">登录</a>
<a href="index.php?query=reg.inc.php">注册</a>

  </body>
</html>