<?php 
include_once "config/fun.php";
$pics=$_COOKIE['funos'];

$sql="SELECT *FROM `userinfo` WHERE user={$pics}";
$result=query($sql);
$row=mysql_fetch_assoc($result);
$picture=$row['picture'];
//echo "<img src=images/{$picture}.jpg/>";
echo <<<AAA
<img src=images/{$picture}.jpg width="50" height="50"/>

AAA;
 


?>